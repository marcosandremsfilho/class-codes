clear all; 
close all; 
clc; 

% Condição inicial 
xt = [ 0 pi 0 0 ]; 

% Simulação do modelo não linear do pêndulo invertido 
ts = ( 0:0.01:5 )'; 
xt = lsode('pendulo', xt, ts); 

figure; 
plot(ts, 100*xt(:,1)); 
grid; 
xlabel('Tempo [s]'); 
ylabel('Posicao do carro [cm]'); 

figure; 
plot(ts, 180/pi*xt(:,2)); 
grid; 
xlabel('Tempo [s]'); 
ylabel('Angulo do pendulo [graus]'); 